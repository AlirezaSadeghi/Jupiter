package model.instruction;

public enum Type {
	ALU ,
	Jump ,
	Branch ,
	Memory ,
	Other ;
}
