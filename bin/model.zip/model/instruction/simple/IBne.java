package model.instruction.simple;

import control.Controller;
import model.Immediate;
import model.Register;
import model.RegisterFile;
import model.instruction.Type;

public class IBne extends IBranch
{
	public IBne(){}
	public IBne(Register rs, Register rt, Immediate immediate) {
		super(rs, rt, immediate);
		Register pc = Controller.getInstance().getRegisterFile().getRegister(RegisterFile.pc);
		if (!rs.equals(rt)) {
			pc.setValue(pc.add((int)immediate.getValue()));
		}
	}

	@Override
	public int getOpCode() {
		return 5;
	}
	
	public String getName() {
		return "bne";
	}
	
	@Override
	public Type getType() {
		return Type.Branch;
	}
	
	

}
